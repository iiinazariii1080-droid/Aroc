import os
import sys
from pathlib import Path

def _add_repo_paths() -> None:
    # Make imports work in both layouts:
    # 1) src-layout: repo_root/src/dryve_d1
    # 2) flat-layout: repo_root/dryve_d1
    here = Path(__file__).resolve()
    repo_root = here.parents[1]  # tests/ -> repo root
    src = repo_root / "src"
    if src.exists() and str(src) not in sys.path:
        sys.path.insert(0, str(src))
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))

_add_repo_paths()
