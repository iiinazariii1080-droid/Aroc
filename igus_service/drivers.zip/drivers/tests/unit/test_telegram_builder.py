from dryve_d1.protocol.gateway_telegram import build_read_adu, build_write_adu, parse_adu
from dryve_d1.protocol.validator import validate_gateway_request


def test_build_read_adu_is_exact_19_bytes():
    adu = build_read_adu(transaction_id=1, unit_id=1, index=0x6041, subindex=0, byte_count=2)
    validate_gateway_request(adu, expect_write=False)
    assert len(adu) == 19
    req = parse_adu(adu)
    assert req.function_code == 0x2B
    assert req.protocol_control == 0
    assert req.index == 0x6041
    assert req.subindex == 0
    assert req.byte_count == 2


def test_build_write_adu_includes_data_and_length_matches():
    adu = build_write_adu(transaction_id=7, unit_id=1, index=0x6040, subindex=0, data=b"\x0f\x00")
    validate_gateway_request(adu, expect_write=True)
    assert len(adu) == 21  # 19 + byte_count(2)
    req = parse_adu(adu)
    assert req.protocol_control == 1
    assert req.byte_count == 2
    assert req.data == b"\x0f\x00"
