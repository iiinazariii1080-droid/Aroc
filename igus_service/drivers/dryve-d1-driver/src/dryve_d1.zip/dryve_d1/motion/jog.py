from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from typing import Optional, Protocol, Literal

from ..od.indices import ODIndex
from ..od.statusword import decode_statusword
from .profile_velocity import ProfileVelocity, ProfileVelocityConfig


class AsyncODAccessor(Protocol):
    async def read_u16(self, index: int, subindex: int = 0) -> int: ...
    async def write_i32(self, index: int, value: int, subindex: int = 0) -> None: ...
    async def write_u8(self, index: int, value: int, subindex: int = 0) -> None: ...
    async def write_u32(self, index: int, value: int, subindex: int = 0) -> None: ...


StopMode = Literal["velocity_zero", "halt"]


@dataclass(frozen=True, slots=True)
class JogConfig:
    """Jog controller configuration.

    TTL semantics:
    - User calls `press()` on button down.
    - While button is held, user calls `keepalive()` periodically (e.g., every 50-100ms).
    - If keepalive does not arrive for ttl_s, controller will stop.

    watch_interval_s should be <= ttl_s / 2 for reliable stop-on-loss.
    """

    ttl_s: float = 0.20
    watch_interval_s: float = 0.05
    stop_mode: StopMode = "velocity_zero"

    require_operation_enabled: bool = True  # verify Statusword bits before starting

    # Optional default profile velocity config for jog
    acceleration: Optional[int] = None
    deceleration: Optional[int] = None
    quick_stop_decel: Optional[int] = None


@dataclass(frozen=True, slots=True)
class JogState:
    active: bool
    velocity: int
    last_update_s: float
    deadline_s: float


class JogController:
    """Hold-to-move jog controller built on Profile Velocity mode.

    This controller is intentionally conservative:
    - It does not perform CiA402 transitions (Enable Operation).
    - It can optionally verify that the drive is in Operation Enabled before moving.
    - It can run a lightweight watchdog asyncio task to stop on TTL expiry.
    """

    def __init__(
        self,
        od: AsyncODAccessor,
        *,
        config: Optional[JogConfig] = None,
    ) -> None:
        self._od = od
        self._cfg = config or JogConfig()

        pv_cfg = ProfileVelocityConfig(
            acceleration=self._cfg.acceleration,
            deceleration=self._cfg.deceleration,
            quick_stop_decel=self._cfg.quick_stop_decel,
            verify_mode=False,
        )
        self._pv = ProfileVelocity(od, config=pv_cfg)

        self._state = JogState(active=False, velocity=0, last_update_s=0.0, deadline_s=0.0)
        self._watch_task: Optional[asyncio.Task] = None
        self._lock = asyncio.Lock()

    @property
    def state(self) -> JogState:
        return self._state

    async def press(self, velocity: int) -> None:
        """Start jog with given signed velocity."""
        async with self._lock:
            await self._ensure_ready_for_motion()
            await self._pv.ensure_mode()
            await self._pv.configure()

            await self._pv.set_target_velocity(int(velocity))
            now = time.monotonic()
            self._state = JogState(
                active=True,
                velocity=int(velocity),
                last_update_s=now,
                deadline_s=now + float(self._cfg.ttl_s),
            )
            self._ensure_watchdog()

    async def keepalive(self, *, velocity: Optional[int] = None) -> None:
        """Refresh TTL and optionally update velocity while button is held."""
        async with self._lock:
            if not self._state.active:
                # If keepalive arrives late, ignore silently; caller can decide to press again.
                return
            if velocity is not None and int(velocity) != int(self._state.velocity):
                await self._pv.set_target_velocity(int(velocity))
                v = int(velocity)
            else:
                v = int(self._state.velocity)

            now = time.monotonic()
            self._state = JogState(active=True, velocity=v, last_update_s=now, deadline_s=now + float(self._cfg.ttl_s))

    async def release(self) -> None:
        """Stop jog explicitly (button up)."""
        async with self._lock:
            await self._stop_locked()

    async def watchdog_tick(self) -> None:
        """One watchdog tick: stop jog if TTL expired.

        You can call this from your own scheduler instead of running our task.
        """
        async with self._lock:
            if not self._state.active:
                return
            if time.monotonic() >= self._state.deadline_s:
                await self._stop_locked()

    async def close(self) -> None:
        """Stop jogging and cancel watchdog task."""
        async with self._lock:
            await self._stop_locked()
        t = self._watch_task
        if t is not None:
            t.cancel()
        self._watch_task = None

    # -----------------------
    # Internals
    # -----------------------
    def _ensure_watchdog(self) -> None:
        if self._watch_task is not None and not self._watch_task.done():
            return
        self._watch_task = asyncio.create_task(self._watchdog_loop(), name="dryve-jog-watchdog")

    async def _watchdog_loop(self) -> None:
        interval = max(0.01, float(self._cfg.watch_interval_s))
        try:
            while True:
                await asyncio.sleep(interval)
                await self.watchdog_tick()
        except asyncio.CancelledError:
            return

    async def _stop_locked(self) -> None:
        if not self._state.active:
            return
        if self._cfg.stop_mode == "velocity_zero":
            await self._pv.stop_velocity_zero()
        else:
            # HALT is optional/drive-dependent; keep velocity_zero as primary.
            await self._pv.halt(enabled=True)
            await self._pv.stop_velocity_zero()
            await self._pv.halt(enabled=False)

        now = time.monotonic()
        self._state = JogState(active=False, velocity=0, last_update_s=now, deadline_s=now)

    async def _ensure_ready_for_motion(self) -> None:
        if not self._cfg.require_operation_enabled:
            return
        sw = await self._od.read_u16(int(ODIndex.STATUSWORD), 0)
        flags = decode_statusword(sw)
        if not flags.get("operation_enabled", False):
            raise RuntimeError(f"Drive not in Operation Enabled; statusword=0x{int(sw) & 0xFFFF:04X}")
        if flags.get("fault", False):
            raise RuntimeError(f"Drive in fault; statusword=0x{int(sw) & 0xFFFF:04X}")
