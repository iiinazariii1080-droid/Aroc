from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Optional, Protocol

from ..od.indices import ODIndex
from ..od.controlword import cw_enable_operation, cw_pulse_new_set_point
from ..od.statusword import SWBit


class AsyncODAccessor(Protocol):
    async def read_u16(self, index: int, subindex: int = 0) -> int: ...
    async def write_u16(self, index: int, value: int, subindex: int = 0) -> None: ...
    async def write_u8(self, index: int, value: int, subindex: int = 0) -> None: ...
    async def write_u32(self, index: int, value: int, subindex: int = 0) -> None: ...


MODE_HOMING = 6


def _bit(word: int, bit: int) -> bool:
    return bool((int(word) >> int(bit)) & 1)


@dataclass(frozen=True, slots=True)
class HomingConfig:
    """Homing configuration.

    Notes:
    - Homing method is drive-specific (see drive manual / DS402 table).
    - Homing speeds (0x6099) commonly use subindex 1 (speed during search)
      and subindex 2 (speed during zero search).
    """

    method: int = 35  # placeholder; must be set to your actual method
    speed_search: Optional[int] = None       # 0x6099:01
    speed_switch: Optional[int] = None       # 0x6099:02
    acceleration: Optional[int] = None       # 0x609A

    poll_interval_s: float = 0.05
    timeout_s: float = 60.0

    verify_mode: bool = False
    mode_set_timeout_s: float = 1.0


@dataclass(frozen=True, slots=True)
class HomingResult:
    attained: bool
    error: bool
    statusword: int


class Homing:
    """Homing mode helper (6060=6)."""

    def __init__(self, od: AsyncODAccessor, *, config: Optional[HomingConfig] = None) -> None:
        self._od = od
        self._cfg = config or HomingConfig()

    async def ensure_mode(self) -> None:
        await self._od.write_u8(int(ODIndex.MODES_OF_OPERATION), MODE_HOMING, 0)
        if not self._cfg.verify_mode:
            return
        deadline = asyncio.get_event_loop().time() + float(self._cfg.mode_set_timeout_s)
        while True:
            mode_disp = await self._od.read_u16(int(ODIndex.MODES_OF_OPERATION_DISPLAY), 0)
            if int(mode_disp) & 0xFF == MODE_HOMING:
                return
            if asyncio.get_event_loop().time() >= deadline:
                raise TimeoutError(f"Timeout waiting for mode display == {MODE_HOMING}")
            await asyncio.sleep(self._cfg.poll_interval_s)

    async def configure(self, *, method: Optional[int] = None, speed_search: Optional[int] = None, speed_switch: Optional[int] = None, acceleration: Optional[int] = None) -> None:
        m = self._cfg.method if method is None else method
        s1 = self._cfg.speed_search if speed_search is None else speed_search
        s2 = self._cfg.speed_switch if speed_switch is None else speed_switch
        acc = self._cfg.acceleration if acceleration is None else acceleration

        # 0x6098 Homing method is typically INT8, but write as U8 (value 0..255) is accepted by most gateways.
        await self._od.write_u8(int(ODIndex.HOMING_METHOD), int(m) & 0xFF, 0)

        if s1 is not None:
            await self._od.write_u32(int(ODIndex.HOMING_SPEEDS), int(s1), 1)
        if s2 is not None:
            await self._od.write_u32(int(ODIndex.HOMING_SPEEDS), int(s2), 2)
        if acc is not None:
            await self._od.write_u32(int(ODIndex.HOMING_ACCELERATION), int(acc), 0)

    async def start(self) -> None:
        """Start homing (pulse NEW_SET_POINT bit in Controlword).
        
        Per manual: start command via bit4 should not be set until required objects
        are configured, and it's recommended to schedule one cycle send/receive as
        a delay before setting start to ensure reliable data adoption.
        
        We ensure this by reading statusword after configuration and before start.
        """
        # Barrier cycle: per manual, wait one cycle after configuration before start
        # Read statusword to ensure reliable data adoption
        await self._od.read_u16(int(ODIndex.STATUSWORD), 0)
        
        # Per manual: after Operation Enabled, bits 0..3 must always be sent
        # Start with base containing hold bits (0x000F)
        base = cw_enable_operation()  # 0x000F = bits 0,1,2,3 set
        # Pulse new_setpoint while preserving hold bits (0..3)
        set_word, clear_word = cw_pulse_new_set_point(base)
        await self._od.write_u16(int(ODIndex.CONTROLWORD), int(set_word) & 0xFFFF, 0)
        await self._od.write_u16(int(ODIndex.CONTROLWORD), int(clear_word) & 0xFFFF, 0)

    async def run(self, *, timeout_s: Optional[float] = None) -> HomingResult:
        """Configure and perform homing, then wait for completion.

        Completion conditions vary between drives. The DS402 convention:
        - Statusword bit 12: Homing attained
        - Statusword bit 13: Homing error
        - Statusword bit 10: Target reached (often also set at end)
        We use bit 12 as 'attained' and bit 13 as 'error' hint.
        """
        await self.ensure_mode()
        await self.configure()
        await self.start()
        return await self.wait_done(timeout_s=timeout_s)

    async def wait_done(self, *, timeout_s: Optional[float] = None) -> HomingResult:
        timeout = self._cfg.timeout_s if timeout_s is None else float(timeout_s)
        deadline = asyncio.get_event_loop().time() + timeout

        while True:
            sw = await self._od.read_u16(int(ODIndex.STATUSWORD), 0)
            # For homing, we interpret bit 12 as "homing attained" (op mode specific)
            attained = _bit(sw, 12)
            # DS402 commonly uses bit 13 as "homing error" (even if our SWBit labels it differently)
            error = _bit(sw, 13)
            if attained or error:
                return HomingResult(attained=attained, error=error, statusword=int(sw) & 0xFFFF)
            if asyncio.get_event_loop().time() >= deadline:
                raise TimeoutError(f"Timeout waiting for homing done. statusword=0x{int(sw) & 0xFFFF:04X}")
            await asyncio.sleep(self._cfg.poll_interval_s)
