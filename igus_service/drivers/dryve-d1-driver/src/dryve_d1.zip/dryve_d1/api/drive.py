from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Optional

from ..config.models import DriveConfig as UserDriveConfig
from ..od.indices import ODIndex
from ..od.controlword import cw_disable_voltage
from ..od.statusword import decode_statusword
from ..protocol import SDOClient

from ..transport import ModbusSession
from ..transport.retry import RetryPolicy as TransportRetryPolicy
from ..transport.session import KeepAliveConfig

from ..transport.clock import monotonic_s

from ..cia402.state_machine import CiA402StateMachine, StateMachineConfig
from ..motion.profile_position import ProfilePosition, ProfilePositionConfig
from ..motion.profile_velocity import ProfileVelocity, ProfileVelocityConfig
from ..motion.homing import Homing, HomingConfig, HomingResult
from ..motion.jog import JogController, JogConfig as MotionJogConfig

@dataclass(frozen=True, slots=True)
class DryveD1Config:
    """High-level configuration for the DryveD1 facade.

    `drive` comes from `dryve_d1.config.models.DriveConfig` (Pydantic model or dataclass fallback),
    and contains connection, retry, polling and soft-limit settings.
    """

    drive: UserDriveConfig
    state_machine: StateMachineConfig = StateMachineConfig()
    profile_position: ProfilePositionConfig = ProfilePositionConfig()
    profile_velocity: ProfileVelocityConfig = ProfileVelocityConfig()
    homing: HomingConfig = HomingConfig()
    jog: MotionJogConfig = MotionJogConfig()


class DryveD1:
    """Async facade for dryve D1 over Modbus TCP Gateway.

    This object owns:
    - ModbusSession (socket + keepalive + serialized transceive)
    - SDOClient (serialization/parsing)
    - CiA402StateMachine runner
    - Motion helpers (profile position, velocity, homing, jog)

    Notes:
    - All OD reads/writes are performed via SDO over the gateway.
    - Networking is blocking under the hood; we offload to threads via `asyncio.to_thread`.
    """

    def __init__(self, *, config: DryveD1Config) -> None:
        """Initialize DryveD1 driver.
        
        According to contract:
        - Preconditions: config != None, config.drive.connection.host non-empty,
          config.drive.connection.port ∈ [1, 65535], config.drive.connection.unit_id ∈ [0, 255],
          all timeout values > 0
        - Postconditions: _session == None, _sm == None, _pp == None, _pv == None,
          _homing == None, _jog == None, is_connected == False
        """
        if config is None:
            raise ValueError("config must not be None")
        
        self._cfg = config

        c = self._cfg.drive.connection
        
        # Validate connection parameters according to contract
        if not c.host or len(c.host.strip()) == 0:
            raise ValueError("config.drive.connection.host must be non-empty")
        if not (1 <= c.port <= 65535):
            raise ValueError(f"config.drive.connection.port must be in range [1, 65535], got {c.port}")
        if not (0 <= c.unit_id <= 255):
            raise ValueError(f"config.drive.connection.unit_id must be in range [0, 255], got {c.unit_id}")
        
        # Validate timeout values (must be > 0)
        if c.connect_timeout_s <= 0:
            raise ValueError(f"config.drive.connection.connect_timeout_s must be > 0, got {c.connect_timeout_s}")
        if c.request_timeout_s <= 0:
            raise ValueError(f"config.drive.connection.request_timeout_s must be > 0, got {c.request_timeout_s}")
        if c.socket_idle_timeout_s <= 0:
            raise ValueError(f"config.drive.connection.socket_idle_timeout_s must be > 0, got {c.socket_idle_timeout_s}")
        
        self._sdo = SDOClient(unit_id=c.unit_id)

        self._session: Optional[ModbusSession] = None

        # Higher-level helpers (created after connect)
        self._sm: Optional[CiA402StateMachine] = None
        self._pp: Optional[ProfilePosition] = None
        self._pv: Optional[ProfileVelocity] = None
        self._homing: Optional[Homing] = None
        self._jog: Optional[JogController] = None

    # -----------------------------
    # Lifecycle
    # -----------------------------
    async def connect(self) -> None:
        if self._session is not None:
            return

        drive_cfg = self._cfg.drive
        c = drive_cfg.connection
        r = drive_cfg.retry
        p = drive_cfg.poll

        # Map config.models.RetryPolicy -> transport.retry.RetryPolicy
        max_attempts = int(r.max_attempts) if getattr(r, "max_attempts", None) is not None else 3
        base_delay_s = float(getattr(r, "base_delay_s", 0.25))
        max_delay_s = float(getattr(r, "max_delay_s", 5.0))
        jitter_s = float(getattr(r, "jitter_s", 0.10))
        jitter_fraction = min(0.90, jitter_s / max(base_delay_s, 1e-6))

        retry_policy = TransportRetryPolicy(
            max_attempts=max_attempts,
            base_delay_s=base_delay_s,
            backoff_factor=2.0,
            max_delay_s=max_delay_s,
            jitter_fraction=jitter_fraction,
        )

        # Keepalive: build a minimal Statusword read (0x6041).
        # The manual indicates the port may close if heartbeats are missing; this avoids idling.
        session: ModbusSession

        # We must create session first to access transaction-id generator inside keepalive builder.
        # Keepalive builder runs from a session-owned thread, so it must be thread-safe and lock-free.
        session = ModbusSession(
            host=c.host,
            port=c.port,
            connect_timeout_s=float(c.connect_timeout_s),
            io_timeout_s=float(c.request_timeout_s),
            retry_policy=retry_policy,
            keepalive=None,  # set below
            logger=getattr(c, "logger", None),
        )

        def build_keepalive_adu() -> bytes:
            tid = session.next_transaction_id()
            req = self._sdo.build_read_int(
                index=int(ODIndex.STATUSWORD),
                subindex=0,
                size=2,
                signed=False,
                transaction_id=tid,
            )
            return req.adu

        keepalive = KeepAliveConfig(
            enabled=True,
            interval_s=float(getattr(p, "keepalive_interval_s", 1.0)),
            build_adu=build_keepalive_adu,
            reconnect_on_error=True,
        )

        # Recreate session with keepalive enabled (cleaner than mutating internals).
        session.close()
        session = ModbusSession(
            host=c.host,
            port=c.port,
            connect_timeout_s=float(c.connect_timeout_s),
            io_timeout_s=float(c.request_timeout_s),
            retry_policy=retry_policy,
            keepalive=keepalive,
            logger=getattr(c, "logger", None),
        )

        await asyncio.to_thread(session.connect)
        self._session = session

        # Build OD-access-based helpers
        self._sm = CiA402StateMachine(self, config=self._cfg.state_machine)
        self._pp = ProfilePosition(self, config=self._cfg.profile_position)
        self._pv = ProfileVelocity(self, config=self._cfg.profile_velocity)
        self._homing = Homing(self, config=self._cfg.homing)
        self._jog = JogController(self, config=self._cfg.jog)

    async def close(self) -> None:
        """Close connection and clean up resources.
        
        According to contract:
        - Must check for active motion operations and raise RuntimeError if present
        - Must stop jog if active
        - Must clear all components (_sm, _pp, _pv, _homing, _jog)
        - Must close TCP connection
        - Must complete within 2.0s
        - Must be idempotent (safe to call multiple times)
        """
        if self._session is None:
            # Already closed, but ensure all components are None
            self._sm = None
            self._pp = None
            self._pv = None
            self._homing = None
            self._jog = None
            return
        
        # Check for active motion operations
        try:
            if self.is_connected:
                # Check if motion is active
                is_moving = await self.is_motion()
                if is_moving:
                    raise RuntimeError("Cannot close() while motion is active. Stop movement first.")
                
                # Check if jog is active
                if self._jog is not None:
                    jog_state = self._jog.state
                    if jog_state.active:
                        # Stop jog before closing
                        try:
                            await self._jog.release()
                        except Exception:
                            pass  # Best effort to stop jog
        except RuntimeError:
            raise  # Re-raise RuntimeError about active motion
        except Exception:
            # If we can't check status (e.g., connection lost), proceed with cleanup
            pass
        
        # Stop jog controller if active (cleanup watchdog task)
        if self._jog is not None:
            try:
                await self._jog.close()
            except Exception:
                pass  # Best effort cleanup
        
        # Close session
        session = self._session
        self._session = None
        await asyncio.to_thread(session.close)
        
        # Clear all components
        self._sm = None
        self._pp = None
        self._pv = None
        self._homing = None
        self._jog = None

    @property
    def is_connected(self) -> bool:
        return self._session is not None and self._session.is_connected

    # -----------------------------
    # Low-level OD access (AsyncODAccessor)
    # -----------------------------
    async def _transceive(self, adu: bytes) -> bytes:
        if self._session is None:
            raise RuntimeError("Not connected")
        deadline = monotonic_s() + float(self._cfg.drive.connection.request_timeout_s)
        return await asyncio.to_thread(self._session.transceive, adu, deadline_s=deadline)

    def _next_tid(self) -> int:
        if self._session is None:
            raise RuntimeError("Not connected")
        return self._session.next_transaction_id()

    async def read_u16(self, index: int, subindex: int = 0) -> int:
        tid = self._next_tid()
        req = self._sdo.build_read_int(index=index, subindex=subindex, size=2, signed=False, transaction_id=tid)
        resp = await self._transceive(req.adu)
        value = self._sdo.decode_read_int(resp, request=req, signed=False) & 0xFFFF
        return value

    async def read_i32(self, index: int, subindex: int = 0) -> int:
        tid = self._next_tid()
        req = self._sdo.build_read_int(index=index, subindex=subindex, size=4, signed=True, transaction_id=tid)
        resp = await self._transceive(req.adu)
        value = int(self._sdo.decode_read_int(resp, request=req, signed=True))
        return value

    async def read_i8(self, index: int, subindex: int = 0) -> int:
        tid = self._next_tid()
        req = self._sdo.build_read_int(index=index, subindex=subindex, size=1, signed=True, transaction_id=tid)
        resp = await self._transceive(req.adu)
        return int(self._sdo.decode_read_int(resp, request=req, signed=True))

    async def write_u16(self, index: int, value: int, subindex: int = 0) -> None:
        tid = self._next_tid()
        req = self._sdo.build_write_int(index=index, subindex=subindex, value=value, size=2, signed=False, transaction_id=tid)
        resp = await self._transceive(req.adu)
        self._sdo.parse_write_response(resp, request=req)

    async def write_u32(self, index: int, value: int, subindex: int = 0) -> None:
        tid = self._next_tid()
        req = self._sdo.build_write_int(index=index, subindex=subindex, value=value, size=4, signed=False, transaction_id=tid)
        resp = await self._transceive(req.adu)
        self._sdo.parse_write_response(resp, request=req)

    async def write_i32(self, index: int, value: int, subindex: int = 0) -> None:
        tid = self._next_tid()
        req = self._sdo.build_write_int(index=index, subindex=subindex, value=value, size=4, signed=True, transaction_id=tid)
        resp = await self._transceive(req.adu)
        self._sdo.parse_write_response(resp, request=req)

    async def write_u8(self, index: int, value: int, subindex: int = 0) -> None:
        tid = self._next_tid()
        req = self._sdo.build_write_int(index=index, subindex=subindex, value=value, size=1, signed=False, transaction_id=tid)
        resp = await self._transceive(req.adu)
        self._sdo.parse_write_response(resp, request=req)

    # -----------------------------
    # High-level controls
    # -----------------------------
    async def enable_operation(self) -> None:
        """Enable operation (bring drive to OPERATION_ENABLED state).
        
        According to contract, this method should use run_to_operation_enabled()
        to handle all valid state transitions from any valid starting state.
        """
        self._require_sm()
        await self._sm.run_to_operation_enabled()

    async def disable_voltage(self) -> None:
        await self.write_u16(int(ODIndex.CONTROLWORD), cw_disable_voltage(), 0)

    async def quick_stop(self) -> None:
        """Request quick stop.
        
        According to contract:
        - Preconditions: is_connected == True, state ∈ {OPERATION_ENABLED, QUICK_STOP_ACTIVE}
        - Postconditions: Final state ∈ {QUICK_STOP_ACTIVE, OPERATION_ENABLED}
        - Movement should start decelerating using QUICK_STOP_DECELERATION (0x6085)
        
        According to the manual, "Quick Stop" stops movement with the rate of deceleration
        previously set at "Motion Limits" (Quick Stop Deceleration, 0x6085).
        This uses a higher deceleration rate than normal stop for emergency situations.
        """
        # Precondition: must be connected
        if not self.is_connected:
            raise RuntimeError("Not connected")
        
        # Precondition: must be in OPERATION_ENABLED or QUICK_STOP_ACTIVE
        status = await self.get_status()
        if not (status.get("operation_enabled", False) or status.get("quick_stop", False)):
            raise RuntimeError("Drive must be in OPERATION_ENABLED or QUICK_STOP_ACTIVE state before quick_stop()")
        
        self._require_sm()
        await self._sm.quick_stop()

    async def stop(self) -> None:
        """Stop movement using normal deceleration.
        
        According to contract:
        - Preconditions: is_connected == True, state ∈ {OPERATION_ENABLED, QUICK_STOP_ACTIVE}
        - Postconditions: Movement stopped with normal deceleration, is_motion() == False
        
        The method automatically detects the current operation mode and uses the
        appropriate stop method:
        - Profile Position mode: Uses HALT bit (bit 8)
        - Profile Velocity mode: Sets target velocity to 0
        - Other modes: Falls back to quick_stop()
        
        Note: This method uses normal deceleration, which is typically slower than
        Quick Stop but safer for normal operation.
        """
        # Precondition: must be connected
        if not self.is_connected:
            raise RuntimeError("Not connected")
        
        # Precondition: must be in OPERATION_ENABLED or QUICK_STOP_ACTIVE
        status = await self.get_status()
        if not (status.get("operation_enabled", False) or status.get("quick_stop", False)):
            raise RuntimeError("Drive must be in OPERATION_ENABLED or QUICK_STOP_ACTIVE state before stop()")
        
        self._require_sm()
        
        # Detect current operation mode
        try:
            mode_display = await self.read_u16(int(ODIndex.MODES_OF_OPERATION_DISPLAY), 0)
            current_mode = int(mode_display) & 0xFF
            
            if current_mode == 1:  # Profile Position mode
                # Use HALT bit for normal deceleration stop in Profile Position
                # Per contract: HALT bit (b8) should be set and cleared
                if self._pp is not None:
                    await self._pp.stop()
                else:
                    # Fallback if _pp not available
                    from ..motion.profile_position import ProfilePosition
                    pp = ProfilePosition(self)
                    await pp.stop()
            elif current_mode == 3:  # Profile Velocity mode
                # Set target velocity to 0 for normal deceleration stop in Profile Velocity
                if self._pv is not None:
                    await self._pv.stop()
                else:
                    # Fallback if _pv not available
                    from ..motion.profile_velocity import ProfileVelocity
                    pv = ProfileVelocity(self)
                    await pv.stop()
            else:
                # For other modes, fall back to quick_stop
                await self.quick_stop()
        except Exception as e:
            # If mode detection fails, fall back to quick_stop
            await self.quick_stop()

    async def emergency_shutdown(self) -> None:
        """Emergency shutdown (alias for disable_voltage).
        
        This is equivalent to disable_voltage() and provided for API compatibility
        with the old driver version.
        
        **Important:** This is NOT a safety-rated emergency stop. This is a logical
        CiA402 shutdown operation that disables voltage via controlword (0x6040).
        For safety-critical applications, use hardware emergency stop circuits.
        
        Per CiA402 standard, this command moves the drive to "Switch on disabled"
        state by clearing all controlword bits (sending 0x0000).
        """
        await self.disable_voltage()

    async def fault_reset(self) -> None:
        self._require_sm()
        await self._sm.fault_reset()

    async def is_homed(self) -> bool:
        """Check if homing has been completed.
        
        Reads the homing status register (0x2014) from the drive.
        Returns True if homing is complete, False otherwise.
        
        Note: This is a dryve D1 specific register. Some drives may not
        support this register, in which case this method may raise an error.
        """
        try:
            homing_status = await self.read_u16(int(ODIndex.HOMING_STATUS), 0)
            # Homing status is typically 1 when homed, 0 when not homed
            return bool(homing_status & 0x01)
        except Exception:
            # If register doesn't exist or read fails, assume not homed
            # This allows the drive to work even if homing status is not available
            return False

    async def move_to_position(
        self,
        *,
        target_position: int,
        velocity: int,
        accel: int,
        decel: int,
        timeout_s: float = 20.0,
        require_homing: bool = True,
    ) -> None:
        """Move to target position.
        
        According to contract:
        - Preconditions: OPERATION_ENABLED, valid parameters within limits
        - Postconditions: Mode = 1, target position set, movement started
        
        Args:
            target_position: Target position in drive units
            velocity: Profile velocity (must be > 0)
            accel: Profile acceleration (must be > 0)
            decel: Profile deceleration (must be > 0)
            timeout_s: Timeout for the move operation (must be > 0)
            require_homing: If True, check that homing is done before moving.
                          If False, skip homing check (use with caution).
        
        Raises:
            RuntimeError: If not connected or not in OPERATION_ENABLED
            ValueError: If parameters are outside valid ranges
            RuntimeWarning: If require_homing=True and not homed
        """
        # Precondition: must be connected
        if not self.is_connected:
            raise RuntimeError("Not connected")
        
        # Precondition: must be in OPERATION_ENABLED
        status = await self.get_status()
        if not status.get("operation_enabled", False):
            raise RuntimeError("Drive must be in OPERATION_ENABLED state before move_to_position()")
        
        # Precondition: REMOTE (bit 9) must be enabled (required for dryve D1)
        if not status.get("remote", False):
            from ..cia402.dominance import PreconditionFailed
            raise PreconditionFailed(
                "Remote not enabled: Statusword bit 9 is LOW (DI7 'Enable' must be HIGH). "
                f"Required for motion operations. statusword=0x{await self.read_u16(int(ODIndex.STATUSWORD)):04X}"
            )
        
        # Parameter validation according to contract
        limits = self._cfg.drive.limits
        
        # Validate timeout
        if timeout_s <= 0:
            raise ValueError(f"timeout_s must be > 0, got {timeout_s}")
        
        # Validate velocity
        if velocity == 0:
            raise ValueError("velocity must be != 0")
        if limits.max_abs_velocity is not None:
            if abs(velocity) > limits.max_abs_velocity:
                raise ValueError(f"velocity {abs(velocity)} exceeds max_abs_velocity {limits.max_abs_velocity}")
        
        # Validate acceleration
        if accel <= 0:
            raise ValueError(f"accel must be > 0, got {accel}")
        if limits.max_abs_accel is not None:
            if accel > limits.max_abs_accel:
                raise ValueError(f"accel {accel} exceeds max_abs_accel {limits.max_abs_accel}")
        
        # Validate deceleration
        if decel <= 0:
            raise ValueError(f"decel must be > 0, got {decel}")
        if limits.max_abs_decel is not None:
            if decel > limits.max_abs_decel:
                raise ValueError(f"decel {decel} exceeds max_abs_decel {limits.max_abs_decel}")
        
        # Validate position (with soft limits)
        if limits.max_abs_position is not None:
            if abs(target_position) > limits.max_abs_position:
                raise ValueError(f"target_position {target_position} exceeds max_abs_position {limits.max_abs_position}")
        
        self._require_pp()
        
        # Check homing status if required (warning, not error per contract)
        if require_homing:
            is_homed = await self.is_homed()
            if not is_homed:
                import warnings
                warnings.warn(
                    "Homing has not been completed. Movement may not work correctly. "
                    "Please perform homing (reference) before moving to position.",
                    RuntimeWarning,
                    stacklevel=2,
                )
        
        await self._pp.move_to_position(
            target_position=target_position,
            profile_velocity=velocity,
            profile_accel=accel,
            profile_decel=decel,
            timeout_s=timeout_s,
        )

    async def home(self, *, timeout_s: float = 30.0) -> HomingResult:
        """Perform homing operation.
        
        According to contract:
        - Preconditions: is_connected == True, state = OPERATION_ENABLED, state != FAULT
        - Preconditions: REMOTE (bit 9) must be enabled (required for dryve D1)
        - Postconditions: Mode = 6, homing completed, is_homed() == True
        """
        # Precondition: must be connected
        if not self.is_connected:
            raise RuntimeError("Not connected")
        
        # Precondition: must be in OPERATION_ENABLED
        status = await self.get_status()
        if not status.get("operation_enabled", False):
            raise RuntimeError("Drive must be in OPERATION_ENABLED state before home()")
        
        # Precondition: must not be in FAULT
        if status.get("fault", False):
            raise RuntimeError("Drive must not be in FAULT state before home()")
        
        # Precondition: REMOTE (bit 9) must be enabled (required for dryve D1)
        if not status.get("remote", False):
            from ..cia402.dominance import PreconditionFailed
            raise PreconditionFailed(
                "Remote not enabled: Statusword bit 9 is LOW (DI7 'Enable' must be HIGH). "
                f"Required for homing operation. statusword=0x{await self.read_u16(int(ODIndex.STATUSWORD)):04X}"
            )
        
        self._require_homing()
        return await self._homing.run(timeout_s=timeout_s)

    # Jog facade
    async def jog_start(self, *, velocity: int, ttl_ms: Optional[int] = None) -> None:
        """Start jogging with given velocity.
        
        According to contract:
        - Preconditions: is_connected == True, state = OPERATION_ENABLED, state != FAULT
        - Preconditions: velocity != 0, abs(velocity) ≤ max_abs_velocity (if limits set)
        - Preconditions: ttl_ms ∈ [50, 5000] (if specified)
        - Postconditions: Mode = 3, target velocity set, motion started
        
        Note: ttl_ms parameter is accepted for API compatibility but the TTL
        is configured in JogConfig when the controller is created.
        """
        # Precondition: must be connected
        if not self.is_connected:
            raise RuntimeError("Not connected")
        
        # Precondition: must be in OPERATION_ENABLED
        status = await self.get_status()
        if not status.get("operation_enabled", False):
            raise RuntimeError("Drive must be in OPERATION_ENABLED state before jog_start()")
        
        # Precondition: must not be in FAULT
        if status.get("fault", False):
            raise RuntimeError("Drive must not be in FAULT state before jog_start()")
        
        # Precondition: REMOTE (bit 9) must be enabled (required for dryve D1)
        if not status.get("remote", False):
            from ..cia402.dominance import PreconditionFailed
            raise PreconditionFailed(
                "Remote not enabled: Statusword bit 9 is LOW (DI7 'Enable' must be HIGH). "
                f"Required for jog operation. statusword=0x{await self.read_u16(int(ODIndex.STATUSWORD)):04X}"
            )
        
        # Parameter validation according to contract
        limits = self._cfg.drive.limits
        
        # Validate velocity
        if velocity == 0:
            raise ValueError("velocity must be != 0")
        if limits.max_abs_velocity is not None:
            if abs(velocity) > limits.max_abs_velocity:
                raise ValueError(f"velocity {abs(velocity)} exceeds max_abs_velocity {limits.max_abs_velocity}")
        
        # Validate ttl_ms if specified
        if ttl_ms is not None:
            if not (50 <= ttl_ms <= 5000):
                raise ValueError(f"ttl_ms must be in range [50, 5000], got {ttl_ms}")
        
        self._require_jog()
        await self._jog.press(velocity=velocity)

    async def jog_update(self, *, velocity: int, ttl_ms: Optional[int] = None) -> None:
        """Update jog velocity and refresh TTL keepalive.
        
        Note: ttl_ms parameter is accepted for API compatibility but the TTL
        is configured in JogConfig when the controller is created.
        """
        self._require_jog()
        await self._jog.keepalive(velocity=velocity)

    async def jog_stop(self) -> None:
        """Stop jogging."""
        self._require_jog()
        await self._jog.release()

    # -----------------------------
    # Status and telemetry
    # -----------------------------
    async def get_position(self) -> int:
        """Get current position from the drive.
        
        Returns the actual position value (0x6064) as a signed 32-bit integer.
        """
        return await self.read_i32(int(ODIndex.POSITION_ACTUAL_VALUE))

    async def is_motion(self) -> bool:
        """Check if the drive is currently in motion.
        
        Returns True if motion is active (target_reached bit is False),
        False if the drive has reached its target or is stationary.
        """
        sw = await self.read_u16(int(ODIndex.STATUSWORD))
        decoded = decode_statusword(sw)
        return not decoded["target_reached"]

    async def get_status(self) -> dict[str, bool]:
        """Get decoded statusword from the drive.
        
        Returns a dictionary of status flags decoded from the statusword (0x6041).
        """
        sw = await self.read_u16(int(ODIndex.STATUSWORD))
        return decode_statusword(sw)

    # -----------------------------
    # Internal helpers
    # -----------------------------
    def _require_sm(self) -> None:
        if self._sm is None:
            raise RuntimeError("Not connected")
    def _require_pp(self) -> None:
        if self._pp is None:
            raise RuntimeError("Not connected")
    def _require_homing(self) -> None:
        if self._homing is None:
            raise RuntimeError("Not connected")
    def _require_jog(self) -> None:
        if self._jog is None:
            raise RuntimeError("Not connected")
