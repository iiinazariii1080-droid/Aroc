"""Transport layer for dryve D1 Modbus TCP Gateway.

Responsibilities:
- TCP socket lifecycle (connect/reconnect/close) with sane timeouts
- Request/response framing for Modbus TCP (MBAP header length-based reads)
- Session orchestration: serialize requests (1 in-flight), keepalive, retry/backoff

The transport layer is intentionally protocol-agnostic: it sends/receives raw ADU bytes.
Protocol validation belongs to `dryve_d1.protocol`.
"""

from .modbus_tcp_client import ModbusTcpClient
from .session import ModbusSession, TransactionIdGenerator
from .retry import RetryPolicy, RetryBudget
from .clock import monotonic_ms, monotonic_s, sleep_s

__all__ = [
    "ModbusTcpClient",
    "ModbusSession",
    "TransactionIdGenerator",
    "RetryPolicy",
    "RetryBudget",
    "monotonic_ms",
    "monotonic_s",
    "sleep_s",
]
