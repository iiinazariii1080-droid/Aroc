"""dryve_d1 - igus dryve D1 Modbus TCP Gateway driver (v2).

Public entry points:
- DryveD1 (async facade)
- MotorManager (optional multi-axis orchestration)
- TelemetryPoller / DriveSnapshot (telemetry helpers)
"""

from .version import __version__

# Public API
from .api.drive import DryveD1
from .api.motor_manager import MotorManager

# Telemetry
from .telemetry.poller import TelemetryPoller, TelemetryConfig
from .telemetry.snapshots import DriveSnapshot

__all__ = [
    "__version__",
    "DryveD1",
    "MotorManager",
    "TelemetryPoller",
    "TelemetryConfig",
    "DriveSnapshot",
]
