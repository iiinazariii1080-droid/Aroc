"""Typed configuration models.

The driver can be used without FastAPI, but many stacks already depend on Pydantic.
We therefore define models with a small compatibility layer for Pydantic v1/v2.

If Pydantic is not available, this module falls back to dataclasses with minimal validation.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .defaults import (
    DEFAULT_CONNECT_TIMEOUT_S,
    DEFAULT_REQUEST_TIMEOUT_S,
    DEFAULT_SOCKET_IDLE_TIMEOUT_S,
    DEFAULT_KEEPALIVE_INTERVAL_S,
    DEFAULT_KEEPALIVE_MISS_LIMIT,
    DEFAULT_STATUS_POLL_S,
    DEFAULT_TELEMETRY_POLL_S,
    DEFAULT_JOG_TTL_MS,
)

try:
    # Pydantic v2
    from pydantic import BaseModel, Field, field_validator
    _PYDANTIC = 2
except Exception:  # pragma: no cover
    try:
        # Pydantic v1
        from pydantic import BaseModel, Field, validator as field_validator  # type: ignore
        _PYDANTIC = 1
    except Exception:  # pragma: no cover
        BaseModel = None  # type: ignore
        Field = None  # type: ignore
        field_validator = None  # type: ignore
        _PYDANTIC = 0


def _require_positive(name: str, v: float) -> float:
    if v <= 0:
        raise ValueError(f"{name} must be > 0")
    return v


def _require_non_negative(name: str, v: float) -> float:
    if v < 0:
        raise ValueError(f"{name} must be >= 0")
    return v


if _PYDANTIC:

    class RetryPolicy(BaseModel):
        """Reconnect/retry policy.

        - max_attempts: None means retry forever (recommended for robots).
        - base_delay_s: initial backoff
        - max_delay_s: clamp backoff
        - jitter_s: add up to +/- jitter_s random jitter (applied in transport layer)
        """

        max_attempts: Optional[int] = Field(default=None, ge=1)
        base_delay_s: float = Field(default=0.25, gt=0)
        max_delay_s: float = Field(default=5.0, gt=0)
        jitter_s: float = Field(default=0.1, ge=0)

        @field_validator("max_attempts")
        def _validate_max_attempts(cls, v):  # type: ignore
            if v is not None and v < 1:
                raise ValueError("max_attempts must be >= 1 or None")
            return v


    class ConnectionConfig(BaseModel):
        host: str = Field(..., min_length=1)
        port: int = Field(default=502, ge=1, le=65535)

        connect_timeout_s: float = Field(default=DEFAULT_CONNECT_TIMEOUT_S, gt=0)
        request_timeout_s: float = Field(default=DEFAULT_REQUEST_TIMEOUT_S, gt=0)
        socket_idle_timeout_s: float = Field(default=DEFAULT_SOCKET_IDLE_TIMEOUT_S, gt=0)

        unit_id: int = Field(default=0x00, ge=0, le=255)  # Modbus Unit ID; often 0 for TCP gateway


    class PollRates(BaseModel):
        status_poll_s: float = Field(default=DEFAULT_STATUS_POLL_S, gt=0)
        telemetry_poll_s: float = Field(default=DEFAULT_TELEMETRY_POLL_S, gt=0)

        keepalive_interval_s: float = Field(default=DEFAULT_KEEPALIVE_INTERVAL_S, gt=0)
        keepalive_miss_limit: int = Field(default=DEFAULT_KEEPALIVE_MISS_LIMIT, ge=1)


    class MotionLimits(BaseModel):
        """Soft limits and validation rules (driver-side guards).

        Units are *drive units* (whatever the device is configured for).
        Provide these from commissioning parameters or vendor documentation.
        """

        max_abs_position: Optional[int] = Field(default=None)  # None => no position clamp
        max_abs_velocity: Optional[int] = Field(default=None)  # None => no velocity clamp
        max_abs_accel: Optional[int] = Field(default=None)     # None => no accel clamp
        max_abs_decel: Optional[int] = Field(default=None)     # None => no decel clamp

        def clamp_position(self, pos: int) -> int:
            if self.max_abs_position is None:
                return pos
            m = int(self.max_abs_position)
            return max(-m, min(m, int(pos)))

        def clamp_velocity(self, vel: int) -> int:
            if self.max_abs_velocity is None:
                return vel
            m = int(self.max_abs_velocity)
            return max(-m, min(m, int(vel)))

        def clamp_accel(self, a: int) -> int:
            if self.max_abs_accel is None:
                return a
            m = int(self.max_abs_accel)
            return max(0, min(m, int(a)))

        def clamp_decel(self, d: int) -> int:
            if self.max_abs_decel is None:
                return d
            m = int(self.max_abs_decel)
            return max(0, min(m, int(d)))


    class JogConfig(BaseModel):
        ttl_ms: int = Field(default=DEFAULT_JOG_TTL_MS, ge=50, le=5000)
        stop_on_ttl_expire: bool = Field(default=True)


    class DriveConfig(BaseModel):
        connection: ConnectionConfig
        retry: RetryPolicy = Field(default_factory=RetryPolicy)
        poll: PollRates = Field(default_factory=PollRates)
        limits: MotionLimits = Field(default_factory=MotionLimits)
        jog: JogConfig = Field(default_factory=JogConfig)

else:
    # Minimal dataclass fallback (no pydantic)
    @dataclass(frozen=True)
    class RetryPolicy:
        max_attempts: Optional[int] = None
        base_delay_s: float = 0.25
        max_delay_s: float = 5.0
        jitter_s: float = 0.1

        def __post_init__(self):
            if self.max_attempts is not None and self.max_attempts < 1:
                raise ValueError("max_attempts must be >= 1 or None")
            _require_positive("base_delay_s", self.base_delay_s)
            _require_positive("max_delay_s", self.max_delay_s)
            _require_non_negative("jitter_s", self.jitter_s)

    @dataclass(frozen=True)
    class ConnectionConfig:
        host: str
        port: int = 502
        connect_timeout_s: float = DEFAULT_CONNECT_TIMEOUT_S
        request_timeout_s: float = DEFAULT_REQUEST_TIMEOUT_S
        socket_idle_timeout_s: float = DEFAULT_SOCKET_IDLE_TIMEOUT_S
        unit_id: int = 0x00

        def __post_init__(self):
            if not self.host:
                raise ValueError("host must be non-empty")
            if not (1 <= int(self.port) <= 65535):
                raise ValueError("port must be 1..65535")
            _require_positive("connect_timeout_s", self.connect_timeout_s)
            _require_positive("request_timeout_s", self.request_timeout_s)
            _require_positive("socket_idle_timeout_s", self.socket_idle_timeout_s)
            if not (0 <= int(self.unit_id) <= 255):
                raise ValueError("unit_id must be 0..255")

    @dataclass(frozen=True)
    class PollRates:
        status_poll_s: float = DEFAULT_STATUS_POLL_S
        telemetry_poll_s: float = DEFAULT_TELEMETRY_POLL_S
        keepalive_interval_s: float = DEFAULT_KEEPALIVE_INTERVAL_S
        keepalive_miss_limit: int = DEFAULT_KEEPALIVE_MISS_LIMIT

        def __post_init__(self):
            _require_positive("status_poll_s", self.status_poll_s)
            _require_positive("telemetry_poll_s", self.telemetry_poll_s)
            _require_positive("keepalive_interval_s", self.keepalive_interval_s)
            if int(self.keepalive_miss_limit) < 1:
                raise ValueError("keepalive_miss_limit must be >= 1")

    @dataclass(frozen=True)
    class MotionLimits:
        max_abs_position: Optional[int] = None
        max_abs_velocity: Optional[int] = None
        max_abs_accel: Optional[int] = None
        max_abs_decel: Optional[int] = None

        def clamp_position(self, pos: int) -> int:
            if self.max_abs_position is None:
                return pos
            m = int(self.max_abs_position)
            return max(-m, min(m, int(pos)))

        def clamp_velocity(self, vel: int) -> int:
            if self.max_abs_velocity is None:
                return vel
            m = int(self.max_abs_velocity)
            return max(-m, min(m, int(vel)))

        def clamp_accel(self, a: int) -> int:
            if self.max_abs_accel is None:
                return a
            m = int(self.max_abs_accel)
            return max(0, min(m, int(a)))

        def clamp_decel(self, d: int) -> int:
            if self.max_abs_decel is None:
                return d
            m = int(self.max_abs_decel)
            return max(0, min(m, int(d)))

    @dataclass(frozen=True)
    class JogConfig:
        ttl_ms: int = DEFAULT_JOG_TTL_MS
        stop_on_ttl_expire: bool = True

        def __post_init__(self):
            if not (50 <= int(self.ttl_ms) <= 5000):
                raise ValueError("ttl_ms must be 50..5000")

    @dataclass(frozen=True)
    class DriveConfig:
        connection: ConnectionConfig
        retry: RetryPolicy = RetryPolicy()
        poll: PollRates = PollRates()
        limits: MotionLimits = MotionLimits()
        jog: JogConfig = JogConfig()
